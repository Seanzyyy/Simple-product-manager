﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fileExtPractise
{
    public partial class Form3 : Form
    {
        List<product> productList = new List<product>();
        string[] products;
        public Form3()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form f2 = new Form2();
            this.Hide();
            f2.ShowDialog();
            this.Close();
        }



        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            string path= openFileDialog1 .FileName;
            if (path != null)
            {
                ReadProductFromFileAndMakeList(path);
                AddDataToList();
            }
        }

        /// <summary>
        /// returns records of products as an array where each index is a record
        /// </summary>
        /// <returns>returns the records of the product as an array </returns>
        private string GetFileData(string path)
        {
            FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);

            string line = sr.ReadLine();
            sr.Close();
            fs.Close();
            return line;
        }
/// <summary>
/// adds strings of data from the file and converts a string to a product
/// object and adds to temporary list
/// </summary>
/// <param name="path"></param>
        private void ReadProductFromFileAndMakeList(string path)
        {
            productList.Clear();

            FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);
            string line;

            while (!sr.EndOfStream)
            {
                line = sr.ReadLine();
                product p = new product(line);
                productList.Add(p);
            }
            sr.Close();
            fs.Close();
        }
/// <summary>
/// displays products objects on the listbox
/// </summary>
        private void AddDataToList()
        {
            listBox1.Items.Clear();
            for(int i = 0; i<productList.Count; i++) 
            {
                listBox1.Items.Add(productList[i].readData()); 
            }
        }

    }
}
