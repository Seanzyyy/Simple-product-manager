﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fileExtPractise
{
    class product
    {
        public string productName, productBrand, price, id;

        /// <summary>
        /// constructor of a product
        /// </summary>
        /// <param name="productName">name for new product</param>
        /// <param name="productBrand">brand of new product</param>
        /// <param name="price">price of new product</param>
        public product(string productName, string productBrand, string price)
        {
            this.productName = productName;
            this.productBrand = productBrand;
            this.price = price;
            this.id = generateID(productName);
        }
        /// <summary>
        /// Create a record of the product and generate an id for it
        /// </summary>
        /// <returns>record of product including id</returns>



        public string generateID(string productName)
        {
            Random random = new Random();
            int x = random.Next(1000, 9999);
            string id = $"{productName[0]}{productName[2]}-{x}";
            return id;
        }
        public product(string pr)
        {
            string[] productInfo = pr.Split('@');
            this.productName = productInfo[0];
            this.productBrand = productInfo[1];
            this.price = productInfo[2];
            this.id = productInfo[3];
        }

        public string getData()
        {
            return $"{productName}@{productBrand}@{price}@{id}";
        }

        public string readData()
        {
            return $"{productName}\t{productBrand}\t{price}\t{id}";
        }






    }
}
