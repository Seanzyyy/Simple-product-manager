﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Pipes;
using static System.Windows.Forms.LinkLabel;

namespace fileExtPractise
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// clicking writes the product info on the txt file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void writeButton_Click(object sender, EventArgs e)
        {
            product product= newProduct();
            writeProductOnFile(product);
            tbPrice.Clear();
            tbProductBrand.Clear();
            tbProductName.Clear();
        }
    
        /// <summary>
        /// 
        /// </summary>
        /// <returns>a new product</returns>
        private product newProduct()
        {
          product product = new product(tbProductName.Text, tbProductBrand.Text, tbPrice.Text);
          return product;
        }
        /// <summary>
        /// This is to record the product on the txt file
        /// </summary>
        private void writeProductOnFile(product product)
        {
            FileStream fileStream = new FileStream("Products.sean", FileMode.Append, FileAccess.Write);
            StreamWriter pen = new StreamWriter(fileStream);
            pen.WriteLine($"{product.getData()} ");

            pen.Close();
            fileStream.Close(); 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            this.Hide();
            f2.ShowDialog();
            this.Close();
        }
    }
}
